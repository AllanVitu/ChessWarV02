<?php

return [
  'db_host' => 'localhost',
  'db_port' => '5432',
  'db_name' => 'vial4802_ChessWar',
  'db_user' => 'vial4802',
  'db_pass' => '@Stell@577!',
  'db_sslmode' => '',
];
