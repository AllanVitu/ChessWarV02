const o=""+new URL("brand-icon-CThbv9w8.png",import.meta.url).href;export{o as l};
