<?php

return [
  'db_host' => 'localhost',
  'db_port' => '5432',
  'db_name' => 'vial4802_ChessWar',
  'db_user' => 'TON_USER',
  'db_pass' => 'TON_MDP',
  'db_sslmode' => '',
];
