<?php

return [
  'db_host' => 'localhost',
  'db_port' => '5432',
  'db_name' => 'vial4802_ChessWar',
  'db_user' => 'vial4802_Kward',
  'db_pass' => '@AllanStell@577!',
  'db_sslmode' => '',
  'realtime_notify_url' => '',
  'realtime_secret' => '',
];
